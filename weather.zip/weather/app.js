window.addEventListener('load', ()=>{

	let lang;
	let lat;
	let temperatureDescription = document.querySelector('.desc');
	let temperatureDegree = document.querySelector('.degree');
	let locationtimezone = document.querySelector('.location-timezone');
	let tempsection = document.querySelector('.temperature');
	const tempspan = document.querySelector('.temperature span');
	if (navigator.geolocation) {

		navigator.geolocation.getCurrentPosition(position => {
			lang = position.coords.longitude;
			lat = position.coords.latitude;
			const proxy = 'https://cors-anywhere.herokuapp.com/';
			const api = `${proxy}https://api.darksky.net/forecast/4db5b1aea736eefaa3d80e30cc0169df/${lat},${lang}`;

			fetch(api)
			.then(response => {
				return response.json();
			})
			.then(data => {
				console.log(data);
				const {temperature , summary , icon} = data.currently;
				temperatureDegree.textContent = temperature;
				temperatureDescription.textContent = summary;
				locationtimezone.textContent = data.timezone;
				let celsius = (temperature - 32) * (5/9);
				//setting icon 
				setIcon(icon, document.querySelector('.icon'));

				//change f to c
				tempsection.addEventListener('click',()=>{
					if (tempspan.textContent === "F") {
						tempspan.textContent = "C";
						temperatureDegree.textContent = Math.floor(celsius) ;
					}
					else {
						tempspan.textContent = "F";
						temperatureDegree.textContent = temperature;
						};
				})
			});
		}) ;
}
	function setIcon(icon,iconID){
		const skycons = new Skycons({ color: "white"});
		const currentIcon = icon.replace(/-/g, "_").toUpperCase();
		skycons.play();
		return skycons.set(iconID,Skycons[currentIcon]);
	}
});